package kg.kompanion.smsdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmsDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
