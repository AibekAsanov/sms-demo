package kg.kompanion.smsdemo.service.impl;

import kg.kompanion.smsdemo.entity.PartitionedSmsRequest;
import kg.kompanion.smsdemo.entity.SmsRequest;
import kg.kompanion.smsdemo.entity.SmsResponse;
import kg.kompanion.smsdemo.repository.SmsResponseRepository;
import kg.kompanion.smsdemo.service.OtpSendService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

@Slf4j
@Service
public class OtpSendServiceImpl implements OtpSendService {

    private final SmsResponseRepository smsResponseRepository;

    @Value("${sms.api.url}")
    private String apiUrl;

    private final RestTemplate restTemplate = new RestTemplate();
    private final ExecutorService executor = new ThreadPoolExecutor(
            10,  // core pool size
            50,  // max pool size
            60L, // idle thread keep-alive time
            TimeUnit.SECONDS,
            new ArrayBlockingQueue<>(1000), // queue size
            new ThreadPoolExecutor.CallerRunsPolicy() // handler for rejected tasks
    );

    public OtpSendServiceImpl(SmsResponseRepository smsResponseRepository) {
        this.smsResponseRepository = smsResponseRepository;
    }

    @Override
    public SmsResponse sendOtp(SmsRequest request) {
        List<String> phones = request.getPhones();
        List<String> oPhones = new ArrayList<>();
        List<String> megaPhones = new ArrayList<>();
        List<String> beelinePhones = new ArrayList<>();

        // Разделение номеров по операторам
        for (String phone : phones) {
            String operatorCode = phone.substring(3, 5);
            if (operatorCode.equals("50") || operatorCode.equals("70")) {
                oPhones.add(phone);
            } else if (operatorCode.equals("55") || operatorCode.equals("75") || operatorCode.equals("99")) {
                megaPhones.add(phone);
            } else if (operatorCode.equals("77") || operatorCode.equals("22")) {
                beelinePhones.add(phone);
            }
        }

        List<Future<SmsResponse>> futures = new ArrayList<>();

        // Отправка OTP сообщений операторам пакетами по 50 номеров
        futures.addAll(sendOtpToOperatorInBatches(request, oPhones));
        futures.addAll(sendOtpToOperatorInBatches(request, megaPhones));
        futures.addAll(sendOtpToOperatorInBatches(request, beelinePhones));

        for (Future<SmsResponse> future : futures) {
            try {
                SmsResponse response = future.get(3, TimeUnit.MINUTES);
                if (response != null) {
                    smsResponseRepository.save(response);
                }
            } catch (TimeoutException e) {
                log.error("OTP sending timeout for request: {}", request);
                return new SmsResponse(request.getTransactionID(), (byte) -1, (short) 0);
            } catch (Exception e) {
                log.error("Error sending OTP for request: {}", request, e);
            }
        }
        return new SmsResponse(request.getTransactionID(), (byte) 1, (short) 1);
    }

    private List<Future<SmsResponse>> sendOtpToOperatorInBatches(SmsRequest request, List<String> phones) {
        List<Future<SmsResponse>> futures = new ArrayList<>();
        List<PartitionedSmsRequest> partitions = partitionList(phones, 50, request.getTransactionID());

        for (PartitionedSmsRequest partition : partitions) {
            futures.add(sendOtpToOperator(request, partition));
        }

        return futures;
    }

    private Future<SmsResponse> sendOtpToOperator(SmsRequest request, PartitionedSmsRequest partition) {
        return executor.submit(() -> {
            try {
                // Создание нового запроса с номерами оператора
                SmsRequest operatorRequest = new SmsRequest(
                        request.getBody(),
                        request.getType(),
                        request.getUsername(),
                        request.getPassword(),
                        partition.getTransactionID(),
                        partition.getPhones()
                );

                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.APPLICATION_JSON);
                HttpEntity<SmsRequest> entity = new HttpEntity<>(operatorRequest, headers);

                ResponseEntity<SmsResponse> responseEntity = restTemplate.postForEntity(apiUrl, entity, SmsResponse.class);
                if (responseEntity.getStatusCode() == HttpStatus.OK) {
                    return responseEntity.getBody();
                } else {
                    log.error("Failed to send OTP. HTTP Status: {}", responseEntity.getStatusCode());
                    return new SmsResponse(partition.getTransactionID(), (byte) -1, (short) 0);
                }
            } catch (Exception e) {
                log.error("Error sending OTP", e);
                return new SmsResponse(partition.getTransactionID(), (byte) -1, (short) 0);
            }
        });
    }

    private List<PartitionedSmsRequest> partitionList(List<String> list, int size, String transactionID) {
        List<PartitionedSmsRequest> partitions = new ArrayList<>();
        for (int i = 0; i < list.size(); i += size) {
            List<String> subList = list.subList(i, Math.min(i + size, list.size()));
            String partitionTransactionID = transactionID + (i / size + 1);
            partitions.add(new PartitionedSmsRequest(partitionTransactionID, subList));
        }
        return partitions;
    }
}
