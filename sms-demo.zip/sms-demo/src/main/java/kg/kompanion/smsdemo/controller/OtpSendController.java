package kg.kompanion.smsdemo.controller;

import kg.kompanion.smsdemo.entity.SmsRequest;
import kg.kompanion.smsdemo.entity.SmsResponse;
import kg.kompanion.smsdemo.service.OtpSendService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/otp")
public class OtpSendController {

    private final OtpSendService otpSendService;

    public OtpSendController(OtpSendService otpSendService) {
        this.otpSendService = otpSendService;
    }

    @PostMapping("/send")
    public ResponseEntity<SmsResponse> sendOtp(@RequestBody SmsRequest request) {
        try {
            SmsResponse response = otpSendService.sendOtp(request);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new SmsResponse(request.getTransactionID(), (byte) -1, (short) 0));
        }
    }
}
