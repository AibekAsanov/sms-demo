package kg.kompanion.smsdemo.service;

import kg.kompanion.smsdemo.entity.SmsRequest;
import kg.kompanion.smsdemo.entity.SmsResponse;

import java.util.List;

public interface SmsSendService {
    List<SmsResponse> processSmsRequest(SmsRequest request);
}
