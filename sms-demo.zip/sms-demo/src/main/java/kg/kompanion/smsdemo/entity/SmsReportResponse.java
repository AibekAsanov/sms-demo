package kg.kompanion.smsdemo.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "sms_report_responses")
public class SmsReportResponse {
    @Id@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private LocalDateTime sendTime;
    private Byte status;
    private String StatusDescription;
    private String phone;
}
