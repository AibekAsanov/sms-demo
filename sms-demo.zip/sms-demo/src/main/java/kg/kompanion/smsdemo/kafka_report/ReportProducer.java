package kg.kompanion.smsdemo.kafka_report;

import kg.kompanion.smsdemo.entity.SmsReportRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class ReportProducer {

    private final KafkaTemplate<String, SmsReportRequest> kafkaTemplate;

    public ReportProducer(KafkaTemplate<String, SmsReportRequest> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void sendMessage(SmsReportRequest request) {
        System.out.println("\n\n\n\n\n\n\n\n" + "Producer: " + request + "\n\n");
        kafkaTemplate.send("sms-report", request);
        log.info("Sent message to Kafka: {}", request);
    }
}
