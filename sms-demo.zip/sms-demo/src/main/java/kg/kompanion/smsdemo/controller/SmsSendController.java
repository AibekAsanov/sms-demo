package kg.kompanion.smsdemo.controller;

import kg.kompanion.smsdemo.entity.SmsRequest;
import kg.kompanion.smsdemo.entity.SmsResponse;
import kg.kompanion.smsdemo.service.SmsSendService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/sms")
public class SmsSendController {

    private final SmsSendService smsSendService;

    public SmsSendController(SmsSendService smsSendService) {
        this.smsSendService = smsSendService;
    }

    @PostMapping("/send")
    public ResponseEntity<SmsResponse> sendSms(@RequestBody SmsRequest request) {
        SmsResponse response = smsSendService.processSmsRequest(request);
        if (response != null) {
            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.status(500).body(null);
        }
    }
}
