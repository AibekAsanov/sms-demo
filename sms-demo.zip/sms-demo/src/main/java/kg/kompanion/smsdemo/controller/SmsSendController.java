package kg.kompanion.smsdemo.controller;

import kg.kompanion.smsdemo.entity.SmsRequest;
import kg.kompanion.smsdemo.entity.SmsResponse;
import kg.kompanion.smsdemo.service.SmsSendService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/sms")
public class SmsSendController {

    private final SmsSendService smsSendService;

    public SmsSendController(SmsSendService smsSendService) {
        this.smsSendService = smsSendService;
    }

    @PostMapping("/send")
    public ResponseEntity<List<SmsResponse>> sendSms(@RequestBody SmsRequest request) {
        List<SmsResponse> responses = smsSendService.processSmsRequest(request);
        if (responses != null) {
            return ResponseEntity.ok(responses);
        } else {
            return ResponseEntity.status(500).body(null);
        }
    }
}
