package kg.kompanion.smsdemo.controller;

import kg.kompanion.smsdemo.entity.SmsReportRequest;
import kg.kompanion.smsdemo.service.SmsReportService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/sms")
public class SmsReportController {

    private final SmsReportService smsReportService;

    public SmsReportController(SmsReportService smsReportService) {
        this.smsReportService = smsReportService;
    }

    @PostMapping("/report")
    public ResponseEntity<String> addToSmsResultQueue(@RequestBody SmsReportRequest request) {
        try {
            smsReportService.addToSmsResultQueue(request);
            return ResponseEntity.ok("Sms report request added to the queue successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error adding sms report request to the queue");
        }
    }
}
