package kg.kompanion.smsdemo.service;

import kg.kompanion.smsdemo.entity.SmsReportRequest;

public interface SmsReportService {
    void addToSmsResultQueue(SmsReportRequest request);
}
