package kg.kompanion.smsdemo.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class SmsRequest {
    private String body;
    private String type;
    private String username;
    private String password;
    private String transactionID;
    private List<String> phones;
}