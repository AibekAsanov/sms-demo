package kg.kompanion.smsdemo.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SmsRequest {
    private String body;
    private String type;
    private String username;
    private String password;
    private String transactionID;
    private List<String> phones;
}