/*
package kg.kompanion.smsdemo.consumer;

import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.KafkaMessageListenerContainer;
import org.springframework.kafka.core.ConsumerFactory;

public class KafkaConsumerRestart {

    private final KafkaMessageListenerContainer<String, String> container;
    private final ConsumerFactory<String, String> consumerFactory;

    public KafkaConsumerRestart(ConsumerFactory<String, String> consumerFactory) {
        this.consumerFactory = consumerFactory;
        ContainerProperties containerProps = new ContainerProperties("SMS_EVENT_TOPIC");
        this.container = new KafkaMessageListenerContainer<>(consumerFactory, containerProps);
    }

    public void restartContainer() {
        container.stop();
        container.start();
    }
}

*/
