package kg.kompanion.smsdemo.service.impl;

import kg.kompanion.smsdemo.service.SmsSendService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import kg.kompanion.smsdemo.entity.PartitionedSmsRequest;
import kg.kompanion.smsdemo.entity.SmsRequest;
import kg.kompanion.smsdemo.entity.SmsResponse;
import kg.kompanion.smsdemo.repository.SmsResponseRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

//TODO: Сделать продюссер для отправки сообщений на проверку
//TODO: Для проверки статуса нужно отправлять каждый пакет по отдельности, потому что у них разные transactionID

@Slf4j
@Service
public class SmsSendServiceImpl implements SmsSendService {

    //TODO: Исправить взятие значения из application.properties
    //@Value("${sms.send.api}")
    private String apiUrl = "http://10.206.154.99:8095/sms/list/telegram";

    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;
    private final SmsResponseRepository smsResponseRepository;

    // Исправление названия конструктора на правильное имя класса
    public SmsSendServiceImpl(SmsResponseRepository smsResponseRepository) {
        this.smsResponseRepository = smsResponseRepository;
        this.restTemplate = new RestTemplate();
        this.objectMapper = new ObjectMapper();
        this.objectMapper.registerModule(new JavaTimeModule());
    }

    private List<PartitionedSmsRequest> partitionList(List<String> list, int size, String transactionID) {
        List<PartitionedSmsRequest> partitions = new ArrayList<>();
        for (int i = 0; i < list.size(); i += size) {
            List<String> subList = list.subList(i, Math.min(i + size, list.size()));
            String partitionTransactionID = transactionID + (i / size + 1);
            partitions.add(new PartitionedSmsRequest(partitionTransactionID, subList));
        }
        return partitions;
    }

    @Override
    public SmsResponse processSmsRequest(SmsRequest request) {
        try {
            List<PartitionedSmsRequest> partitions = partitionList(request.getPhones(), 50, request.getTransactionID());
            for (PartitionedSmsRequest partition : partitions) {
                SmsRequest partitionedRequest = new SmsRequest(
                        request.getBody(),
                        request.getType(),
                        request.getUsername(),
                        request.getPassword(),
                        partition.getTransactionID(),
                        partition.getPhones()
                );

                String jsonRequest = objectMapper.writeValueAsString(partitionedRequest);
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.APPLICATION_JSON);
                HttpEntity<String> entity = new HttpEntity<>(jsonRequest, headers);
                ResponseEntity<String> responseEntity = restTemplate.postForEntity(apiUrl, entity, String.class);

                if (responseEntity.getStatusCode() == HttpStatus.OK) {
                    SmsResponse smsResponse = objectMapper.readValue(responseEntity.getBody(), SmsResponse.class);
                    smsResponseRepository.save(smsResponse);
                    log.info("Processed SMS. Transaction ID: {}, Status: {}, Description: {}, Parts: {}",
                            smsResponse.getTransactionID(), smsResponse.getStatus(), smsResponse.getPartsOfSMS());
                    return smsResponse;
                } else {
                    log.error("Failed to process SMS. HTTP Status: {}", responseEntity.getStatusCode());
                }
            }
        } catch (Exception e) {
            log.error("Exception occurred while processing SMS", e);
        }
        return null;
    }
}
