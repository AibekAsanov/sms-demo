package kg.kompanion.smsdemo.service.impl;

import kg.kompanion.smsdemo.kafka_report.ReportProducer;
import kg.kompanion.smsdemo.service.SmsSendService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import kg.kompanion.smsdemo.entity.PartitionedSmsRequest;
import kg.kompanion.smsdemo.entity.SmsRequest;
import kg.kompanion.smsdemo.entity.SmsResponse;
import kg.kompanion.smsdemo.entity.SmsReportRequest;
import kg.kompanion.smsdemo.repository.SmsResponseRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class SmsSendServiceImpl implements SmsSendService {

    @Value("${sms.send.api}")
    private String apiUrl = "http://localhost:8080/sms/send";

    @Value("${sms.username}")
    private String username = "test";

    @Value("${sms.password}")
    private String password = "test123";

    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;
    private final SmsResponseRepository smsResponseRepository;
    private final ReportProducer kafkaProducerService;

    //@Value("${sms.report.controller.url}")
    private String smsReportControllerUrl = "http://localhost:8080/sms/report";

    public SmsSendServiceImpl(SmsResponseRepository smsResponseRepository, ReportProducer kafkaProducerService) {
        this.smsResponseRepository = smsResponseRepository;
        this.kafkaProducerService = kafkaProducerService;
        this.restTemplate = new RestTemplate();
        this.objectMapper = new ObjectMapper();
        this.objectMapper.registerModule(new JavaTimeModule());
    }

    private List<PartitionedSmsRequest> partitionList(List<String> list, int size, String transactionID) {
        List<PartitionedSmsRequest> partitions = new ArrayList<>();
        for (int i = 0; i < list.size(); i += size) {
            List<String> subList = list.subList(i, Math.min(i + size, list.size()));
            String partitionTransactionID = transactionID + (i / size + 1);
            partitions.add(new PartitionedSmsRequest(partitionTransactionID, subList));
        }
        return partitions;
    }

    @Override
    public List<SmsResponse> processSmsRequest(SmsRequest request) {
        try {
            List<SmsResponse> responses = new ArrayList<>();
            List<PartitionedSmsRequest> partitions = partitionList(request.getPhones(), 50, request.getTransactionID());

            for (PartitionedSmsRequest partition : partitions) {
                SmsRequest partitionedRequest = new SmsRequest(
                        request.getBody(),
                        request.getType(),
                        request.getUsername(),
                        request.getPassword(),
                        partition.getTransactionID(),
                        partition.getPhones()
                );

                String jsonRequest = objectMapper.writeValueAsString(partitionedRequest);
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.APPLICATION_JSON);
                HttpEntity<String> entity = new HttpEntity<>(jsonRequest, headers);
                ResponseEntity<String> responseEntity = restTemplate.postForEntity(apiUrl, entity, String.class);

                if (responseEntity.getStatusCode() == HttpStatus.OK) {
                    SmsResponse smsResponse = objectMapper.readValue(responseEntity.getBody(), SmsResponse.class);
                    smsResponseRepository.save(smsResponse);
                    log.info("Processed SMS. Transaction ID: {}, Status: {}, Parts: {}",
                            smsResponse.getTransactionID(), smsResponse.getStatus(), smsResponse.getPartsOfSMS());
                    responses.add(smsResponse);

                    // Отправка сообщения на проверку через Kafka
                    SmsReportRequest reportRequest = new SmsReportRequest();
                    reportRequest.setTransactionID(smsResponse.getTransactionID());
                    reportRequest.setUsername(request.getUsername());
                    reportRequest.setPassword(request.getPassword());

                    //TODO: Исправить сериализацию ответов в reportConsumer
                    //kafkaProducerService.sendMessage(reportRequest);
                    sendToController(reportRequest);
                } else {
                    log.error("Failed to process SMS. HTTP Status: {}", responseEntity.getStatusCode());
                }
            }
            return responses;
        } catch (Exception e) {
            log.error("Exception occurred while processing SMS", e);
        }
        return null;
    }

    private void sendToController(SmsReportRequest request) {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<SmsReportRequest> entity = new HttpEntity<>(request, headers);
            restTemplate.postForEntity(smsReportControllerUrl, entity, String.class);
            log.info("Sent report to controller: {}", request);
        } catch (Exception e) {
            log.error("Failed to send report: {}", e.getMessage(), e);
        }
    }
}
