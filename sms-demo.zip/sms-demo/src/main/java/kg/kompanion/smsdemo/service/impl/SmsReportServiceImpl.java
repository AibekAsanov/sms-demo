package kg.kompanion.smsdemo.service.impl;

import kg.kompanion.smsdemo.entity.SmsReportReCheck;
import kg.kompanion.smsdemo.entity.SmsReportRequest;
import kg.kompanion.smsdemo.entity.SmsReportResponse;
import kg.kompanion.smsdemo.repository.SmsReportResponseRepository;
import kg.kompanion.smsdemo.service.SmsReportService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.*;

@Slf4j
@Service
public class SmsReportServiceImpl implements SmsReportService {

    private final SmsReportResponseRepository smsReportResponseRepository;
    private final ScheduledExecutorService scheduler;
    private final ExecutorService executorService;

    //@Value("${sms.username}")
    private String username = "test";

    //@Value("${sms.password}")
    private String password = "test123";

    //@Value("${sms.report.controller.url}")
    private String checkApi = "http://10.206.154.99:8095/report/list";

    //@Value("{sms.recheck}")
    private String recheckApi = "http://localhost:8080/sms/report";

    private final RestTemplate restTemplate = new RestTemplate();

    public SmsReportServiceImpl(SmsReportResponseRepository smsReportResponseRepository) {
        this.smsReportResponseRepository = smsReportResponseRepository;
        this.scheduler = Executors.newScheduledThreadPool(10);  // Настроить количество потоков в зависимости от нагрузки
        this.executorService = Executors.newFixedThreadPool(20);  // Пул потоков для асинхронной обработки
    }

    @Override
    public void addToSmsResultQueue(SmsReportRequest request) {
        log.info("Adding request to SMS result queue. TransactionID: {}", request.getTransactionID());
        // TODO: later back to waiting 3 minutes
        //LocalDateTime scheduledTime = LocalDateTime.now().plusMinutes(3);
        LocalDateTime scheduledTime = LocalDateTime.now().plusSeconds(3);
        CheckStatusTask task = new CheckStatusTask(request);
        scheduler.schedule(task, Duration.between(LocalDateTime.now(), scheduledTime).toMillis(), TimeUnit.MILLISECONDS);
    }

    private class CheckStatusTask implements Runnable {
        private final SmsReportRequest request;

        public CheckStatusTask(SmsReportRequest request) {
            this.request = request;
        }

        @Override
        public void run() {
            log.info("Starting CheckStatusTask for TransactionID: {}", request.getTransactionID());
            CompletableFuture.runAsync(() -> {
                try {
                    SmsReportRequest newRequest = new SmsReportRequest();
                    newRequest.setTransactionID(request.getTransactionID());
                    newRequest.setUsername(username);
                    newRequest.setPassword(password);

                    HttpHeaders headers = new HttpHeaders();
                    headers.setContentType(MediaType.APPLICATION_JSON);
                    HttpEntity<SmsReportRequest> entity = new HttpEntity<>(newRequest, headers);

                    log.info("Sending request to check API for TransactionID: {}", request.getTransactionID());
                    ResponseEntity<List<SmsReportResponse>> responseEntity = restTemplate.exchange(
                            checkApi,
                            HttpMethod.POST,
                            entity,
                            new ParameterizedTypeReference<List<SmsReportResponse>>() {
                            });

                    if (responseEntity.getStatusCode() == HttpStatus.OK) {
                        List<SmsReportResponse> responses = responseEntity.getBody();
                        log.info("Received {} responses for TransactionID: {}", responses.size(), request.getTransactionID());
                        for (SmsReportResponse response : responses) {
                            if (response.getStatus().equals(0) || response.getStatus().equals(1) || response.getStatus().equals(6)) {
                                log.info("Status {} for TransactionID: {}. Scheduling retry in 3 minutes for phone: {}", response.getStatus(), request.getTransactionID(), response.getPhone());
                                SmsReportReCheck statusReCheck = new SmsReportReCheck();
                                statusReCheck.setTransactionID(request.getTransactionID());
                                statusReCheck.setUsername(username);
                                statusReCheck.setPassword(password);
                                statusReCheck.setPhone(response.getPhone());

                                scheduler.schedule(() -> retrySendingSms(statusReCheck), 3, TimeUnit.MINUTES);
                                smsReportResponseRepository.save(response);
                            } else {
                                log.info("Saving response with status {} for TransactionID: {}. Phone: {}", response.getStatus(), request.getTransactionID(), response.getPhone());
                                smsReportResponseRepository.save(response);
                            }
                        }
                    } else {
                        log.error("Failed to check SMS status for TransactionID {}. HTTP Status: {}", request.getTransactionID(), responseEntity.getStatusCode());
                    }
                } catch (Exception e) {
                    log.error("Exception occurred while checking SMS status for TransactionID {}", request.getTransactionID(), e);
                }
            }, executorService).whenComplete((result, throwable) -> {
                if (throwable != null) {
                    log.error("Error in async task for checking status of TransactionID {}", request.getTransactionID(), throwable);
                } else {
                    log.info("Completed CheckStatusTask for TransactionID: {}", request.getTransactionID());
                }
            });
        }

        private void retrySendingSms(SmsReportReCheck reCheck) {
            log.info("Starting retrySendingSms for TransactionID: {}", reCheck.getTransactionID());
            CompletableFuture.runAsync(() -> {
                try {
                    HttpHeaders headers = new HttpHeaders();
                    headers.setContentType(MediaType.APPLICATION_JSON);
                    HttpEntity<SmsReportReCheck> entity = new HttpEntity<>(reCheck, headers);

                    log.info("Sending retry request to recheck API for TransactionID: {}", reCheck.getTransactionID());
                    ResponseEntity<SmsReportResponse> response = restTemplate.exchange(
                            recheckApi,
                            HttpMethod.POST,
                            entity,
                            SmsReportResponse.class);

                    if (response.getStatusCode().is2xxSuccessful()) {
                        SmsReportResponse responseBody = response.getBody();
                        if (responseBody != null && (responseBody.getStatus().equals(0) || responseBody.getStatus().equals(1) || responseBody.getStatus().equals(6))) {
                            log.info("Retrying SMS sending for TransactionID: {}. Scheduling next retry in 3 minutes for phone: {}", reCheck.getTransactionID(), reCheck.getPhone());
                            scheduler.schedule(() -> retrySendingSms(reCheck), 3, TimeUnit.MINUTES);
                        } else {
                            log.info("Saving response for TransactionID: {}. Phone: {}", reCheck.getTransactionID(), reCheck.getPhone());
                            smsReportResponseRepository.save(responseBody);
                        }
                    } else {
                        log.error("Failed to retry SMS for TransactionID {}. HTTP Status: {}", reCheck.getTransactionID(), response.getStatusCode());
                    }
                } catch (Exception e) {
                    log.error("Exception occurred while retrying SMS for TransactionID {}", reCheck.getTransactionID(), e);
                }
            }, executorService).whenComplete((result, throwable) -> {
                if (throwable != null) {
                    log.error("Error in async task for retrying SMS of TransactionID {}", reCheck.getTransactionID(), throwable);
                } else {
                    log.info("Completed retrySendingSms for TransactionID: {}", reCheck.getTransactionID());
                }
            });
        }
    }
}
