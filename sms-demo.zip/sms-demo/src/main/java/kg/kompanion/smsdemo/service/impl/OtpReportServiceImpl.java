package kg.kompanion.smsdemo.service.impl;

import kg.kompanion.smsdemo.service.OtpReportService;

import kg.kompanion.smsdemo.entity.SmsReportRequest;
import kg.kompanion.smsdemo.entity.SmsReportResponse;
import kg.kompanion.smsdemo.repository.SmsReportResponseRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.*;

@Slf4j
@Service
public class OtpReportServiceImpl implements OtpReportService {

    private final SmsReportResponseRepository smsReportResponseRepository;
    private final BlockingQueue<SmsReportRequest> smsResultQueue = new LinkedBlockingQueue<>();
    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(10);

    @Value("${sms.username}")
    private String username;

    @Value("${sms.password}")
    private String password;

    @Value("${sms.result.api.url}")
    private String apiUrl;

    private final RestTemplate restTemplate = new RestTemplate();

    public OtpReportServiceImpl(SmsReportResponseRepository smsReportResponseRepository) {
        this.smsReportResponseRepository = smsReportResponseRepository;
    }

    @Override
    public void addToSmsResultQueue(SmsReportRequest request) {
        smsResultQueue.offer(request);

        LocalDateTime scheduledTime = LocalDateTime.now().plusMinutes(3);
        CheckStatusTask task = new CheckStatusTask(request);
        scheduler.schedule(task, Duration.between(LocalDateTime.now(), scheduledTime).toMillis(), TimeUnit.MILLISECONDS);
    }

    private class CheckStatusTask implements Runnable {
        private final SmsReportRequest request;

        public CheckStatusTask(SmsReportRequest request) {
            this.request = request;
        }

        @Override
        public void run() {
            try {
                SmsReportRequest newRequest = new SmsReportRequest();
                newRequest.setTransactionID(request.getTransactionID());
                newRequest.setUsername(username);
                newRequest.setPassword(password);

                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.APPLICATION_JSON);
                HttpEntity<SmsReportRequest> entity = new HttpEntity<>(newRequest, headers);

                ResponseEntity<List<SmsReportResponse>> responseEntity = restTemplate.exchange(
                        apiUrl,
                        HttpMethod.POST,
                        entity,
                        new ParameterizedTypeReference<List<SmsReportResponse>>() {});

                if (responseEntity.getStatusCode() == HttpStatus.OK) {
                    List<SmsReportResponse> responses = responseEntity.getBody();
                    for (SmsReportResponse response : responses) {
                        if (response.getStatus().equals(0) || response.getStatus().equals(1) || response.getStatus().equals(6)) {
                            smsResultQueue.offer(request); // повторная отправка в очередь
                        } else {
                            smsReportResponseRepository.save(response);
                        }
                        log.info("Checked SMS status for transactionID: {}. Phone: {}, Send Time: {}, Status: {}, Description: {}",
                                request.getTransactionID(), response.getPhone(), response.getSendTime(),
                                response.getStatus(), response.getStatusDescription());
                    }
                } else {
                    log.error("Failed to check SMS status for transactionID {}. HTTP Status: {}", request.getTransactionID(), responseEntity.getStatusCode());
                }
            } catch (Exception e) {
                log.error("Exception occurred while checking SMS status for transactionID {}", request.getTransactionID(), e);
            }
        }
    }
}

