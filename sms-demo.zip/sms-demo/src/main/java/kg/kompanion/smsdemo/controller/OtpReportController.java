package kg.kompanion.smsdemo.controller;

import kg.kompanion.smsdemo.entity.SmsReportRequest;
import kg.kompanion.smsdemo.service.OtpReportService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/otp")
public class OtpReportController {

    private final OtpReportService smsOtpStatusService;

    public OtpReportController(OtpReportService smsOtpStatusService) {
        this.smsOtpStatusService = smsOtpStatusService;
    }

    @PostMapping("/report")
    public ResponseEntity<String> checkSmsStatus(@RequestBody SmsReportRequest request) {
        try {
            smsOtpStatusService.addToSmsResultQueue(request);
            return ResponseEntity.ok("Sms status check scheduled successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error scheduling sms status check");
        }
    }
}
