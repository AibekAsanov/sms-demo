package kg.kompanion.smsdemo.repository;

import kg.kompanion.smsdemo.entity.SmsResponse;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SmsResponseRepository extends JpaRepository<SmsResponse, Long> {
}
