package kg.kompanion.smsdemo.service;

import kg.kompanion.smsdemo.entity.SmsRequest;
import kg.kompanion.smsdemo.entity.SmsResponse;

public interface OtpSendService {
    SmsResponse sendOtp(SmsRequest request);
}
