package kg.kompanion.smsdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmsDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SmsDemoApplication.class, args);
    }

}
