package kg.kompanion.smsdemo.kafka_report;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import kg.kompanion.smsdemo.entity.SmsReportRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.Duration;
import java.util.Collections;
import java.util.Properties;

@Slf4j
@Service
public class ReportConsumer {

    private final ObjectMapper objectMapper;
    private final RestTemplate restTemplate;

    //@Value("${sms.report.controller.url}")
    private String smsReportControllerUrl = "http://localhost:8080/sms/report";

    public ReportConsumer(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
        this.restTemplate = new RestTemplate();
    }

    @KafkaListener(topics = "sms-report", groupId = "sms-report-consumer-group")
    public void consume() {
        Properties props = new Properties();
        props.put("bootstrap.servers", "10.206.73.201:9092");
        props.put("group.id", "sms-report-consumer-group");
        props.put("key.deserializer", StringDeserializer.class.getName());
        props.put("value.deserializer", StringDeserializer.class.getName());

        org.apache.kafka.clients.consumer.KafkaConsumer<String, String> consumer = new org.apache.kafka.clients.consumer.KafkaConsumer<>(props);
        consumer.subscribe(Collections.singletonList("sms-report"));

        try {
            while (true) {
                ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(100));
                for (ConsumerRecord<String, String> record : records) {
                    log.info("Received message from broker partition = {}, offset = {}, key = {}, value = {}",
                            record.partition(), record.offset(), record.key(), record.value());

                    JsonNode messageJson = objectMapper.readTree(record.value());
                    String transactionID = messageJson.path("transactionID").asText();
                    String username = messageJson.path("username").asText();
                    String password = messageJson.path("password").asText();

                    SmsReportRequest smsReportRequest = new SmsReportRequest();
                    smsReportRequest.setTransactionID(transactionID);
                    smsReportRequest.setUsername(username);
                    smsReportRequest.setPassword(password);

                    sendToController(smsReportRequest);
                }
            }
        } catch (Exception e) {
            log.error("Error consuming Kafka message", e);
        } finally {
            consumer.close();
        }
    }

    private void sendToController(SmsReportRequest request) {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<SmsReportRequest> entity = new HttpEntity<>(request, headers);
            restTemplate.postForEntity(smsReportControllerUrl, entity, String.class);
            log.info("Sent report to controller: {}", request);
        } catch (Exception e) {
            log.error("Failed to send report: {}", e.getMessage(), e);
        }
    }
}
