package kg.kompanion.smsdemo.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "sms_responses")
public class SmsResponse {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String transactionID;
    private Byte status;
    private Short partsOfSMS;

    public SmsResponse(String transactionID, Byte status, Short partsOfSMS) {
        this.transactionID = transactionID;
        this.status = status;
        this.partsOfSMS = partsOfSMS;
    }
}