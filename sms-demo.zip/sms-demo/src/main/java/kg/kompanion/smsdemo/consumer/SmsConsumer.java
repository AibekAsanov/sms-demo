package kg.kompanion.smsdemo.consumer;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import kg.kompanion.smsdemo.entity.SmsRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class SmsConsumer {

    private final ObjectMapper objectMapper;
    private final RestTemplate restTemplate;

    //TODO: исправить взятие значений из application.properties
    //@Value("${sms.username}")
    private String username = "test";

    //@Value("${sms.password}")
    private String password = "test123";

    //@Value("${sms.controller.url}")
    private String sendSmsUrl = "http://localhost:8080/sms/send";

    public SmsConsumer() {
        this.objectMapper = new ObjectMapper();
        this.objectMapper.registerModule(new JavaTimeModule());
        this.restTemplate = new RestTemplate();
    }

    @KafkaListener(topics = "sms", groupId = "sms-consumer-group")
    public void listenSmsRequests(ConsumerRecord<String, String> record, Acknowledgment acknowledgment) {
        String message = record.value();
        log.info("Received message from 'sms' topic: {}", message);
        try {
            JsonNode messageJson = objectMapper.readTree(message);
            List<SmsRequest> requests = new ArrayList<>();
            for (JsonNode jsonNode : messageJson) {
                SmsRequest request = new SmsRequest(
                        jsonNode.path("body").asText(),
                        jsonNode.path("type").asText(),
                        username,
                        password,
                        jsonNode.path("transactionID").asText(),
                        objectMapper.convertValue(jsonNode.path("phone"), List.class)
                );
                requests.add(request);
            }
            for (SmsRequest request : requests) {
                ResponseEntity<String> response = restTemplate.postForEntity(sendSmsUrl, request, String.class);
                log.info("Response from SMS send endpoint: {}", response.getBody());
            }
            acknowledgment.acknowledge();
        } catch (Exception e) {
            log.error("Error processing SMS request", e);
        }
    }
}
