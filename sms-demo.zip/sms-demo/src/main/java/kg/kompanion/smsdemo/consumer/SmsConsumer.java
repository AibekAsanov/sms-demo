package kg.kompanion.smsdemo.consumer;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import kg.kompanion.smsdemo.entity.SmsRequest;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.common.serialization.StringDeserializer;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.Duration;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

@Service
@Slf4j
public class SmsConsumer {

    private final ObjectMapper objectMapper;
    private final RestTemplate restTemplate;

    public SmsConsumer(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
        this.restTemplate = new RestTemplate();
    }

    //TODO: исправить взятие значений из application.properties
    //@Value("${sms.username}")
    private String username = "test";

    //@Value("${sms.password}")
    private String password = "test123";

    //@Value("${sms.controller.url}")
    private String sendSmsUrl = "http://localhost:8080/sms/send";

    @KafkaListener(topics = "sms-event", groupId = "2")
    public void consume() {
        Properties props = new Properties();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "10.206.73.201:9092");
        props.put(ConsumerConfig.GROUP_ID_CONFIG, "my-group");
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());

        org.apache.kafka.clients.consumer.KafkaConsumer<String, String> consumer = new org.apache.kafka.clients.consumer.KafkaConsumer<>(props);
        consumer.subscribe(Collections.singletonList("sms-event"));
        try {
            while (true) {
                ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(100));
                for (ConsumerRecord<String, String> record : records) {
                    System.out.printf("Received message from broker %s, offset = %d, key = %s, value = %s%n",
                            record.partition(), record.offset(), record.key(), record.value());
                    System.out.println("\n\n");

                    JsonNode messageJson = objectMapper.readTree(record.value());
                    String body = messageJson.path("message").asText();
                    String type = messageJson.path("source").asText();
                    String transactionId = messageJson.path("transaction_id").asText();
                    List<String> phones = objectMapper.convertValue(
                            messageJson.path("phone"),
                            objectMapper.getTypeFactory().constructCollectionType(List.class, String.class)
                    );
                    SmsRequest smsRequest = new SmsRequest();
                    smsRequest.setBody(body);
                    smsRequest.setType(type);
                    smsRequest.setTransactionID(transactionId);
                    smsRequest.setUsername(username);
                    smsRequest.setPassword(password);
                    smsRequest.setPhones(phones);

                    ResponseEntity<String> response = restTemplate.postForEntity(sendSmsUrl, smsRequest, String.class);
                    log.info("Response from SMS send endpoint: {}", response.getBody());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            consumer.close();
        }
    }
}
